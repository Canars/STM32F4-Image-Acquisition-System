#ifndef __OS_H__
#define __OS_H__

#define Sleep(x) OSTimeDlyHMSM(0,0,0,x)

#endif // __OS_H__
