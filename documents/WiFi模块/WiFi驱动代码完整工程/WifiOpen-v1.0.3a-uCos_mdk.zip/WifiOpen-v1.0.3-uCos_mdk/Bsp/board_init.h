#ifndef __BOARD_INIT_H__
#define __BOARD_INIT_H__
//
// Macros definitions
//

//
// Exported functions declare
//
BOOL Board_Init ();

#endif // __BOARD_INIT_H__
